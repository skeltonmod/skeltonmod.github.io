﻿
# The game starts here.
label start:
    call persona_quest
    return
