﻿## how to use this fucking shit of a code:
##
## 1. drop this file in your game/ folder. that's it. renpy finds it on its own, no imports, no bullshit.
##
## 2. add your quests to QUESTS below. each one needs a title, a description and a list of steps.
##    the key (like "lost_cat") is the quest id. pick it once and never fucking rename it,
##    or old saves will lose track of the quest.
##
## 3. in your script, boss the quests around with these:
##      $ start_quest("lost_cat")       starts it at step 1. does nothing if it already started.
##      $ advance_quest("lost_cat")     next step. on the last step it completes the damn thing.
##      $ complete_quest("lost_cat")    skips straight to done.
##      $ fail_quest("lost_cat")        you screwed it up. congrats.
##
## 4. check on them with if statements:
##      if quest_active("lost_cat"):
##      if quest_done("lost_cat"):
##      if quest_failed("lost_cat"):
##      if quest_step("lost_cat") == 1:     steps start at 0, because programmers are like that. -1 means not started.
##
## 5. in-game, press q or click "quests" in the corner to open the log.
##
## want to see it work? fuck you!


## your quests go here. copy one of these blocks and change the shit inside it.
define QUESTS = {
    "lost_cat": {
        "title": "The Lost Cat",
        "description": "Mira's cat Biscuit went missing last night. She's worried sick.",
        "steps": [
            "Ask around town about Biscuit.",
            "Search the old well behind the inn.",
            "Return Biscuit to Mira.",
        ],
    },
    "bakers_delivery": {
        "title": "Baker's Delivery",
        "description": "The baker needs a basket of bread taken up the hill to the chapel.",
        "steps": [
            "Pick up the bread basket at the bakery.",
            "Deliver the basket to the chapel.",
        ],
    },
    "sebec": {
        "title": "The SEBEC Incident",
        "description": "A dumb after-school ritual went very right. Now the town is full of demons and it's apparently your problem.",
        "steps": [
            "Play the Persona game.",
            "Visit Maki at the hospital.",
            "Get out of the hospital alive.",
            "Figure out what's going on in town.",
            "Get inside the SEBEC building.",
            "Stop Kandori.",
        ],
    },
    "dubious_love": {
        "title": "Dubious Love",
        "description": "Ten years later, you're trying to date. Your options are questionable.",
        "steps": [
            "Pick someone to date.",
            "Survive the first date.",
            "Survive the second date.",
            "Confess. Or don't.",
        ],
    },
}


init -10 python:

    class QuestState(object):
        def __init__(self):
            self.status = "inactive"
            self.step = 0

default quest_states = {}


init -5 python:

    def _quest_state(qid):
        if qid not in QUESTS:
            raise Exception("Unknown quest id: %r" % qid)
        if qid not in quest_states:
            quest_states[qid] = QuestState()
        return quest_states[qid]

    def quest_title(qid):
        return QUESTS[qid]["title"]

    def quest_status(qid):
        if qid not in quest_states:
            return "inactive"
        return quest_states[qid].status

    def quest_active(qid):
        return quest_status(qid) == "active"

    def quest_done(qid):
        return quest_status(qid) == "completed"

    def quest_failed(qid):
        return quest_status(qid) == "failed"

    def quest_step(qid):
        if quest_status(qid) == "inactive":
            return -1
        return quest_states[qid].step

    def start_quest(qid, notify=True):
        q = _quest_state(qid)
        if q.status != "inactive":
            return
        q.status = "active"
        q.step = 0
        if notify:
            renpy.notify("New quest: " + quest_title(qid))

    def advance_quest(qid, notify=True):
        q = _quest_state(qid)
        if q.status != "active":
            return
        if q.step < len(QUESTS[qid]["steps"]) - 1:
            q.step += 1
            if notify:
                renpy.notify("Quest updated: " + quest_title(qid))
        else:
            complete_quest(qid, notify)

    def complete_quest(qid, notify=True):
        q = _quest_state(qid)
        if q.status in ("completed", "failed"):
            return
        q.status = "completed"
        q.step = len(QUESTS[qid]["steps"]) - 1
        if notify:
            renpy.notify("Quest complete: " + quest_title(qid))

    def fail_quest(qid, notify=True):
        q = _quest_state(qid)
        if q.status in ("completed", "failed"):
            return
        q.status = "failed"
        if notify:
            renpy.notify("Quest failed: " + quest_title(qid))

    def quests_with_status(status):
        return [qid for qid in QUESTS if quest_status(qid) == status]

    ## don't want the quests button in the corner? delete this line and the button is gone. q still won't work either, so make your own damn button.
    config.overlay_screens.append("quest_button")


## colors and text sizes for the log. if it looks like crap, fiddle with these.
style quest_header is label_text:
    size 28
    color "#f5d27a"

style quest_title_text is text:
    size 36
    color "#ffffff"

style quest_body_text is text:
    size 22
    color "#dddddd"

style quest_list_button_text is button_text:
    size 22
    idle_color "#cccccc"
    hover_color "#ffffff"
    selected_color "#f5d27a"


screen quest_button():
    zorder 50
    key "q" action ToggleScreen("quest_log")
    if not renpy.get_screen("quest_log"):
        textbutton "Quests":
            align (0.98, 0.02)
            action Show("quest_log")


screen quest_log():
    modal True
    zorder 100

    default selected = None

    add Solid("#000000b0")

    frame:
        align (0.5, 0.5)
        xysize (1200, 700)
        padding (30, 30)

        hbox:
            spacing 40

            viewport:
                xsize 380
                scrollbars "vertical"
                mousewheel True
                draggable True

                vbox:
                    spacing 6

                    for header, status in (("Active", "active"),
                                           ("Completed", "completed"),
                                           ("Failed", "failed")):
                        $ ids = quests_with_status(status)
                        if ids:
                            null height 10
                            text header style "quest_header"
                            for qid in ids:
                                textbutton quest_title(qid):
                                    text_style "quest_list_button_text"
                                    action SetScreenVariable("selected", qid)
                                    selected selected == qid

                    if not quest_states:
                        text "No quests yet." style "quest_body_text"

            vbox:
                spacing 16
                xfill True

                if selected is None:
                    text "Select a quest." style "quest_body_text"
                else:
                    $ data = QUESTS[selected]
                    $ status = quest_status(selected)
                    $ cur = quest_step(selected)

                    text data["title"] style "quest_title_text"
                    text "Status: [status!c]" style "quest_body_text"
                    text data["description"] style "quest_body_text"

                    null height 10
                    text "Objectives" style "quest_header"

                    for i, step in enumerate(data["steps"]):
                        if i < cur or status == "completed":
                            text "{s}" + step + "{/s}" style "quest_body_text" color "#888888"
                        elif i == cur:
                            text "> " + step style "quest_body_text" color "#ffffff"

    textbutton "Close":
        align (0.97, 0.95)
        action Hide("quest_log")

