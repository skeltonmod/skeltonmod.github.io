init 1 python:

    # shove it in the damn dict. Again.
    QUESTS["sebec"] = {
        "title": "The SEBEC Incident",
        "description": "Something is wrong in Mikage-cho. The corporation on the hill "
                       "is involved, because of course it is.",
        "steps": [
            "Play the 'Persona' game in the classroom.",
            "Visit Maki in the hospital.",
            "Escape the hospital.",
            "Find the Velvet Room.",
            "Get into the SEBEC building.",
            "Confront Kandori.",
        ],
    }

    QUESTS["dubious_love"] = {
        "title": "Dubious Love",
        "description": "Ten years after SEBEC. You're an adult, you're lonely, and your "
                       "dating pool is made of people who should not be in a dating pool.",
        "steps": [
            "Pick someone. Bad idea no matter who.",
            "Survive the first date.",
            "Survive the second date.",
            "Confess, God help you.",
        ],
    }

    CONTACT_MOODS = {
        "anger": "The demon is furious. It attacks!",
        "fear":  "The demon panics and flees. A win, technically.",
        "happy": "The demon is delighted. It leaves you a gift and wanders off.",
        "eager": "The demon is eager! It hands over a spell card.",
    }

    # toook me a while to balance this crap and it's still broken.
    DATES = {
        "Igor": {
            "intro": "You meet in the Velvet Room. It's the only place he goes. The pianist won't stop staring.",
            "yes": "I have foreseen this moment. I did not foresee agreeing to it. And yet.",
            "no": "A pity. Your fate is your own. Please leave the way you came. Now.",
            "options": {
                "Bring flowers": (0, "He puts them in a vase that was somehow always there."),
                "Offer him spell cards": (2, "His grin gets wider. You didn't think that was physically possible."),
                "Ask about his past": (-1, "He just keeps smiling. For a full minute. Silently."),
                "Request a duet with the pianist": (1, "The pianist plays. Igor hums. You have no idea what's happening."),
            },
        },
        "Kandori": {
            "intro": "Kandori somehow survived and now runs a café. The coffee is good. The espresso machine is named DEVA.",
            "yes": "...Fine. But I'm choosing the restaurant. And the reality it exists in.",
            "no": "Get out of my café.",
            "options": {
                "Bring flowers": (-1, "He stares at them until they wilt. You're not sure how."),
                "Praise his machine": (2, "He talks about it for forty minutes. He seems happy. Genuinely."),
                "Ask how he's really doing": (1, "A long pause. 'Nobody's asked me that before.' Oof."),
                "Mention SEBEC": (-2, "The temperature drops. A cup cracks on its own."),
            },
        },
        "Jack Frost": {
            "intro": "Jack Frost shows up in a tiny bow tie. Honestly, he's trying harder than you.",
            "yes": "Hee-ho! You've got yourself a frosty sweetheart, ho!",
            "no": "Hee-ho... that was cold. And I'd know, ho.",
            "options": {
                "Get ice cream": (2, "He's thrilled. He eats the cone, the cup and part of the table."),
                "Take him to a sauna": (-2, "He gets noticeably smaller. You leave early."),
                "Tell him a pun": (1, "He laughs so hard a light frost covers the restaurant."),
                "Bring flowers": (0, "They freeze solid. He says he likes them better that way."),
            },
        },
    }


default spell_cards = 0
default persona_name = None
default partner = None
default affection = {}


define p_mark  = Character("Mark")
define p_nanjo = Character("Nanjo")
define p_elly  = Character("Elly")
define p_maki  = Character("Maki")
define p_phil  = Character("Philemon", color="#c8b6ff")
define p_igor  = Character("Igor", color="#6fa8ff")
define p_kand  = Character("Kandori", color="#ff6b6b")
define p_jack  = Character("Jack Frost", color="#9fe3ff")

define DATE_CHARS = {"Igor": p_igor, "Kandori": p_kand, "Jack Frost": p_jack}


label contact(demon):
    "A [demon] blocks the way."

    menu:
        "Mark: Dance":
            $ mood = renpy.random.choice(["happy", "eager", "anger"])
        "Nanjo: Lecture it on manners":
            $ mood = renpy.random.choice(["anger", "fear", "eager"])
        "Elly: Flatter it in English":
            $ mood = renpy.random.choice(["happy", "eager", "fear"])
        "Just fight it":
            "Violence. The most reliable form of communication."
            return

    # renpy chokes on nested brackets in text, so here's a stupid temp variable. Thanks.
    $ mood_text = CONTACT_MOODS[mood]
    "[mood_text]"

    if mood == "eager":
        $ spell_cards += 1
        "Spell cards: [spell_cards]. Something for Igor to grind into a new self."
    elif mood == "anger":
        "You beat it anyway. Diplomacy has failed, as is tradition."
    return


label persona_quest:

    scene black
    "St. Hermelin High. After school. Bored students, a rumor, and very poor judgement."

    $ start_quest("sebec")

    p_mark "Okay, so you stand in the corners and say the chant. Supposedly someone shows up."
    p_nanjo "This is beneath me. I'm doing it anyway."
    p_elly "Whoever appears, I hope they're polite."

    "You all join hands. The room goes cold. The lights go out."
    "Then there's nothing at all. Fitting."

    p_phil "You came looking for something. Fine. A piece of yourself, then. Try not to lose it."

    # if they leave it blank I'm not fixing it, it's "Nameless". Deal with it.
    $ persona_name = renpy.input("Your Persona whispers its name:", length=16).strip() or "Nameless"
    "[persona_name] awakens. Congratulations, you're a mask now."

    $ advance_quest("sebec")

    "Everyone wakes up on the classroom floor. Someone suggests the hospital. Partly to check yourselves. Mostly to see Maki."

    p_maki "You came! It's so dull here. Tell me everything."
    p_mark "Just some dumb game. Nothing happened."
    "Something happened."

    "The building shakes. Screaming in the hallway. Things with too many teeth in the hallway."

    $ advance_quest("sebec")

    call contact("Pixie")
    call contact("Jack Frost")

    "You make it outside. The town looks the same. It is not the same."

    $ advance_quest("sebec")

    "A blue door that wasn't there yesterday. Naturally, you open it."

    p_igor "Welcome to the Velvet Room. Your fate brought you here. Your poor decisions helped."

    if spell_cards > 0:
        p_igor "You have [spell_cards] spell card(s). Give me a little time, and I can make you someone new."
        "You hand them over. Identity is negotiable, apparently."
        $ spell_cards = 0
    else:
        p_igor "Empty-handed. A pity. Come back when the demons have been more generous."

    $ advance_quest("sebec")

    "The SEBEC building looms over Mikage-cho. A whole tower for one man's ego. Very efficient."

    menu:
        "Sneak in through the back":
            "The back door is unlocked. Security is a rumor, like the Persona game."
        "Walk in through the front":
            "The guards are already demons. Corporate culture."
            call contact("Gate guard")

    $ advance_quest("sebec")

    p_kand "Children. Here, in my building, presuming to matter."
    p_nanjo "Big words from a man hiding behind a machine."
    p_kand "The machine is reality now. You're simply standing in it."

    menu:
        "Call on [persona_name]":
            "[persona_name] answers. For once, something does."
            $ complete_quest("sebec")
            "Kandori falls. The town will still be weird tomorrow, but at least this part is over."
        "Hesitate":
            "You hesitate. The universe does not."
            $ fail_quest("sebec")
            "GAME OVER. Same ending, just sooner."
            return

    call dating_sim
    return


label dating_sim:

    scene black
    "Ten years later."
    "You're an adult with a desk job and a SEBEC-shaped hole in your life. Time to date, apparently."

    $ start_quest("dubious_love")

    menu:
        "Who's the unlucky one?"
        "Igor":
            $ partner = "Igor"
        "Kandori, somehow alive and running a café":
            $ partner = "Kandori"
        "Jack Frost":
            $ partner = "Jack Frost"

    $ affection[partner] = 0
    $ advance_quest("dubious_love")

    $ date_intro = DATES[partner]["intro"]
    "[date_intro]"

    call date_round
    $ advance_quest("dubious_love")

    "Against all odds, there's a second date."

    call date_round
    $ advance_quest("dubious_love")

    $ hearts = affection[partner]
    "Affection: [hearts]. Whatever the hell that means."

    menu:
        "Confess":
            # 3 points. it's arbitrary and no i'm not changing it.
            if hearts >= 3:
                $ renpy.say(DATE_CHARS[partner], DATES[partner]["yes"])
                $ complete_quest("dubious_love")
                "You're dating [partner] now. Your mother is going to have questions."
            else:
                $ renpy.say(DATE_CHARS[partner], DATES[partner]["no"])
                $ fail_quest("dubious_love")
                "Rejected. By [partner]. Sit with that."
        "Panic and leave":
            $ fail_quest("dubious_love")
            "You fake a phone call and run. Classic."

    return


label date_round:
    # display_menu because a normal menu can't loop a dict. why the fuck not, renpy.
    $ pick = renpy.display_menu([(k, k) for k in DATES[partner]["options"]])
    $ gained, reaction = DATES[partner]["options"][pick]
    $ affection[partner] += gained
    "[reaction]"

    if gained > 0:
        "[partner] seems to like that. Somehow."
    elif gained < 0:
        "Well, shit."
    return
